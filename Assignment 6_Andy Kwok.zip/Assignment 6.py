# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Andy Kwok, 4/28/2018, Added code to complete assignment 5
#   Andy Kwok, 5/06/2018, Changed code to complete assignment 6
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection
# nextword = String that stores a character read from text file
# entry1 = String of task input
# entry2 = String of priority input
# datalist = A list for the top level program
# list1 = A list for function input
# list2 = A list for function input
# list3 = A list for function input
# list4 = A list for function input

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove an existing item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# -------------------------------

global objFileName
objFileName = "C:\\Users\Andy - PC\PycharmProjects\IT FDN 100\Todo.txt"

# Function class that stores various function for this program
class Function(object):

    @staticmethod
    def Loading():
        lstTable = []
        nextword = ""
        entry1 = ""
        entry2 = ""
        strData = ""
        dicRow = {}
        openfile = open(objFileName, "r")
        for strData in openfile:  # read each line of data from text file
            for i in range(len(strData)):  # seperating the task and priority by filtering out the comma
                if nextword != 'y':
                    if strData[i] is ",":
                        nextword = "y"
                    else:
                        entry1 += strData[i]
                else:
                    entry2 += strData[i]
            dicRow = {"Task": entry1.strip(),
                      "Priority": entry2.strip()}  # saving task and priority in form of a dictionary
            lstTable.append(dicRow)  # add each dictionary entry into a list
            dicRow = {}  # flushing the variables for extracting data from the next line
            nextword = "n"
            entry1 = ""
            entry2 = ""
        openfile.close()
        return lstTable

    @staticmethod
    def Saving(list4):
        openfile = open(objFileName, "w")
        for item in list4:
            savetext = item.get("Task") + "," + item.get("Priority")
            # saving each dictionary element in each row in existing format
            openfile.write(savetext + "\n")
        openfile.close()
        return

    @staticmethod
    def Showing(list1):
        for item in list1:  # read each dictionary element list element
            print("Taxsk ID:", list1.index(item), "\t Task:", item.get("Task"), "\t Prirority:", item.get("Priority"))
        return

    @staticmethod
    def Adding(list2):
        entry1 = str(input("What is the name of your task?"))
        entry2 = str(input("What priority do you wish to assign it to?"))
        dicRow = {"Task": entry1.strip(), "Priority": entry2.strip()}  # placing the entries into a dictionary element
        list2.append(dicRow)  # added the dictionary element into the list
        return list2

    @staticmethod
    def Removing(list3):
        itemdel = "n"
        deltask = str(input("Which task do you want to delete?"))
        for item in list3:  # review each dictionary element
            reviewtask = item.get("Task")
            if deltask.lower() == reviewtask.lower():  # matching the input with each task in the dictionary
                print("This task has been deleted.")
                del list3[list3.index(item)]
                itemdel = "y"
        if itemdel == "n":  # let user know if no matching task was found
            print("Task not founded. Nothing has been deleted.")
        return list3

# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"
datalist = Function.Loading()

# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line
    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        Function.Showing(datalist)
        continue
    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        datalist = Function.Adding(datalist)
        continue
    # Step 5 - Remove a existing item to the list/Table
    elif (strChoice == '3'):
        datalist = Function.Removing(datalist)
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        Function.Saving(datalist)
        continue
    elif (strChoice == '5'):
        break  # and Exit the program


